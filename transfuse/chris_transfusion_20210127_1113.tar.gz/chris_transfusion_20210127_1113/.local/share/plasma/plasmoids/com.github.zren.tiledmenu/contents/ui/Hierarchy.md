Main
	SearchModel
		SearchResultsModel
	LauncherIcon
	Popup
		SearchView
			SidebarView
			SearchResultsView
				SearchResultsList
			SearchField
		TileGrid


krunner_id (filename)

org.kde.activities (activityrunner)
Audio Player Control Runner (audioplayercontrol)
baloosearch (baloosearch)
bookmarks (bookmarks)
calculator (calculator)
unitconverter (converter)
org.kde.datetime (datetime)
Dictionary (dictionary)
Kill Runner (kill)
kwin (kwin)
locations (locations)
places (places)
Name=plasma-desktop (plasma)
PowerDevil (powerdevil)
services (services)
desktopsessions (sessions)
shell (shell)
Spell Checker (spellchecker)
webshortcuts (webshortcuts)
org.kde.windowedwidgets (windowedwidgets)
windows (windows)
